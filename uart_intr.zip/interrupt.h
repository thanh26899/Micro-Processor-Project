#ifndef INTERRUPT_H
#define INTERRUPT_H
#include "uart.h"
#include "spi.h"

void __interrupt() ISR(void);

#endif